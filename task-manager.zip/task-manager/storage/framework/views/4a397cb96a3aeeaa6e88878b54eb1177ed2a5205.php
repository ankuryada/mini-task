<!DOCTYPE html>
<html>

<head>
    <title>Mini Task Management System</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container mt-4">
        <h1>Task Management System</h1>

        <!-- Form to add a new task -->
        <div class="card mb-4">
            <div class="card-header">Add New Task</div>
            <div class="card-body">
                <form id="taskForm">
                    <div class="form-group">
                        <label for="title">Title*</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Task Title">
                    </div>
                    <div class="form-group">
                        <label for="description">Description (Optional)</label>
                        <textarea class="form-control" id="description" name="description" placeholder="Task Description"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="priority">Priority*</label>
                        <select class="form-control" id="priority" name="priority">
                            <option value="">Select Priority</option>
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="due_date">Due Date*</label>
                        <input type="date" class="form-control" id="due_date" name="due_date">
                    </div>
                    <div class="form-group">
                        <label for="status">Status*</label>
                        <select class="form-control" id="status" name="status">
                            <option value="Pending">Pending</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Task</button>
                </form>
            </div>
        </div>

        <!-- Task List -->
        <div class="card">
            <div class="card-header">Tasks</div>
            <div class="card-body">
                <table class="table" id="tasksTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Priority</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Tasks will be loaded here via AJAX -->
                    </tbody>
                </table>
                <!-- Pagination Links -->
                <nav>
                    <ul class="pagination" id="pagination"></ul>
                </nav>
            </div>
        </div>
    </div>

    <!-- jQuery for AJAX calls -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            // Set CSRF Token for AJAX requests
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Function to fetch tasks with pagination
            function fetchTasks(page = 1) {
                $.ajax({
                    url: `/api/tasks?page=${page}`,
                    type: 'GET',
                    success: function(data) {
                        var tbody = '';
                        $.each(data.data, function(index, task) {
                            tbody += `<tr>
                        <td>${task.id}</td>
                        <td>${task.title}</td>
                        <td>${task.priority}</td>
                        <td>${task.due_date}</td>
                        <td>${task.status}</td>
                        <td>
                            <button class="btn btn-danger btn-sm delete-task" data-id="${task.id}">Delete</button>
                        </td>
                    </tr>`;
                        });
                        $('#tasksTable tbody').html(tbody);

                        // Build pagination links
                        var pagination = '';
                        for (var i = 1; i <= data.last_page; i++) {
                            pagination += `<li class="page-item ${data.current_page == i ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>`;
                        }
                        $('#pagination').html(pagination);
                    }
                });
            }

            // Initial fetch of tasks
            fetchTasks();

            // Pagination link click event
            $(document).on('click', '.page-link', function(e) {
                e.preventDefault();
                var page = $(this).data('page');
                fetchTasks(page);
            });

            // Handle form submission for adding a new task
            $('#taskForm').on('submit', function(e) {
                e.preventDefault();
                var formData = {
                    title: $('#title').val(),
                    description: $('#description').val(),
                    priority: $('#priority').val(),
                    due_date: $('#due_date').val(),
                    status: $('#status').val()
                };
                $.ajax({
                    url: '/api/tasks',
                    type: 'POST',
                    data: formData,
                    success: function(data) {
                        alert('Task added successfully!');
                        $('#taskForm')[0].reset();
                        fetchTasks();
                    },
                    error: function(xhr) {
                        alert('Error: ' + JSON.stringify(xhr.responseJSON.errors));
                    }
                });
            });

            // Handle task deletion
            $(document).on('click', '.delete-task', function() {
                if (confirm("Are you sure you want to delete this task?")) {
                    var id = $(this).data('id');
                    $.ajax({
                        url: `/api/tasks/${id}`,
                        type: 'DELETE',
                        success: function(data) {
                            alert(data.message);
                            fetchTasks();
                        }
                    });
                }
            });
        });
    </script>
</body>

</html><?php /**PATH C:\xampp-7.4.1\htdocs\task-manager\resources\views\tasks\index.blade.php ENDPATH**/ ?>